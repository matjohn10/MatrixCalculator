import main


def run():
    main.main()
