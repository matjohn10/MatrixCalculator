from matrixcalc.main import main


def run():
    main()
